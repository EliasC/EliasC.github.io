#include "list.h"
#include <stdlib.h>
#include <stdio.h>

typedef struct link link_t;

struct link {
  char *elem;
  link_t *next;
};

static link_t *link_create(char *elem, link_t *next) {
  link_t *link = calloc(1, sizeof(link_t));
  link->elem = elem;
  link->next = next;
  return link;
}

struct list {
  link_t *first;
  // TODO: Extend me
};

list_t *list_create(void) {
  list_t *list = calloc(1, sizeof(list_t));
  return list;
}

void list_destroy(list_t *l) {
  link_t *cursor = l->first;
  while (cursor) {
    link_t *next = cursor->next;
    free(cursor);
    cursor = next;
  }
  free(l);
}

bool list_insert(list_t *l, char *s, int index) {
  if (index == 0) {
    l->first = link_create(s, l->first);
    return true;
  }

  link_t *cursor = l->first;
  for (int i = 1; i < index; ++i){
    if (!cursor) {
      return false;
    }
    cursor = cursor->next;
  }

  if (!cursor) {
    return false;
  }

  cursor->next = link_create(s, cursor->next);
  return true;
}

char *list_get(list_t *l, int index) {
  // TODO: Extend me
  if(index < 0) {
    return NULL;
  }

  link_t *cursor = l->first;

  for (int i = 0; i < index; ++i){
    if (!cursor) {
      return NULL;
    }
    cursor = cursor->next;
  }
  if (!cursor) {
    return NULL;
  }

  return cursor->elem;
}

void list_insert_at_latest(list_t *l, char *s) {
  // TODO: Implement me
}

char *list_remove_at_latest(list_t *l) {
  // TODO: Implement me
  return NULL;
}

#ifndef TEST
int main(void)
{
  puts("If you want to you can write test code here and run it using `make run`");
  return 0;
}
#endif