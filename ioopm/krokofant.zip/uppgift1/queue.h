#pragma once

#include <stdbool.h>
#include <stdlib.h>
#include <stddef.h>

typedef void queue_t;
typedef union elem elem_t;

union elem
{
  int i;
  void *p;
  bool b;
};

/// Create a new empty queue
queue_t *queue_new();

/// Delete the queue
void queue_free(queue_t *);

/// Add element at the back of a queue
void queue_offer(queue_t *, elem_t);

/// Remove the element at the front of the queue.
///
/// Will succeed if queue_size(q) > 0.
/// If successful, store the element in the place pointed to by e.
///
/// \param q pointer to the queue
/// \param e pointer to where the element can be stored
/// Returns true if succeeded, else false
bool queue_take_first(queue_t *q, elem_t *e);

/// Like queue_take_first except takes from the back of the queue
bool queue_take_last(queue_t *q, elem_t *e);

/// Like queue_take_first, except e is not removed from q
bool queue_peek_first(queue_t *q, elem_t *e);

/// Like queue_peek_first except peeks at the back of the queue
bool queue_peek_last(queue_t *q, elem_t *e);

/// Returns the number of elements in the queue
size_t queue_size(queue_t *);