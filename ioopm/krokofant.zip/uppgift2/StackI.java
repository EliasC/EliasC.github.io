public interface StackI<T> {
    // Push an element onto the stack
    public void push(T element);
    // Pop the top element from the stack
    // Throws StackUnderflowException if the stack is empty
    public T pop();
    // Get the top element from the stack without removing it
    // Throws StackUnderflowException if the stack is empty
    public T top();
    // Returns true if the stack is empty, and false otherwise
    public boolean isEmpty();
}