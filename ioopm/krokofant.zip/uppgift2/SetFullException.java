/// To be thrown when a set exceeds its max capacity
public class SetFullException extends RuntimeException {}
