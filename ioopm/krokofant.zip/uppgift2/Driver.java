import java.util.Iterator;

public class Driver {
    private static boolean soft = false;
    private static int mod = java.lang.reflect.Modifier.PRIVATE;

    public static void prod(boolean exp, String msg) {
        if (soft == false) {
            assert exp : msg;
        } else {
            if (exp == false) System.err.println(msg);
        }
    }
    public static void main(String[] args) throws ClassNotFoundException {
        soft = args.length == 1 && args[0].equalsIgnoreCase("soft");
        if (soft) {
            System.out.println("NOTE: testing in soft mode!");
        }

        Integer[] ints   = new Integer[] { 1, 2, 3, 4, 1000, 2000, 3000, 4000 };
        Integer[] copies = new Integer[ints.length];
        for (int i = 0; i < ints.length; ++i) copies[i] = Integer.valueOf(ints[i]);
        Driver.test(ints, copies);
    }
    public static void test(Integer[] elements, Integer[] copies) throws ClassNotFoundException {
        /// Testing Contains
        TreeSet<String> foo = new TreeSet<String>(1);
        foo.add(new String("Strung"));
        prod(foo.contains("Strung"),"Contains seems broken");

        for (java.lang.reflect.Field f : foo.getClass().getDeclaredFields()) {
            prod((f.getModifiers() & mod) > 0, "Seems you have forgotten about encapsulation of fields!");
        }

        /// Testing ADD
        TreeSet<Integer> l = new TreeSet<Integer>(elements.length + 2);
        Collection<Integer> c = l;
        for (int i = 0; i < elements.length; ++i) {
            l.add(elements[i]);
        }
        prod(c.size() == elements.length,"Set has wrong size!");
        for (int i = 0; i < elements.length; ++i) {
            l.add(elements[i]);
        }
        prod(c.size() == elements.length,"Set is a multi-sst (but should not be) (identitical duplicates found)");
        for (int i = 0; i < copies.length; ++i) {
            l.add(copies[i]);
        }
        prod(c.size() == elements.length,"Set is a multi-set (but should not be) (equivalent duplicates found)");

        for (int i = 0; i < copies.length; ++i) {
            prod(l.contains(copies[i]),"Contains seems broken -- expected " + copies[i] + " in set");
        }
        for (int i = 0; i < elements.length; ++i) {
            prod(l.contains(elements[i]),"Contains seems broken -- expected " + elements[i] + " in set");
        }

        Collection<Integer> copy = Collection.copy(c);
        prod(copy instanceof TreeSet,"TreeSet does not override copy()!");
        // ((Set<Integer>) copy).remove(elements[0]);

        // prod(((Set<Integer>) copy).size() < c.size(),"Remove seems broken 1 ");
        // prod(((Set<Integer>) copy).contains(elements[0]) == false,"Remove seems broken 2 ");

        TreeSet<Integer> i1 = new TreeSet<Integer>(10);
        TreeSet<Integer> i2 = new TreeSet<Integer>(10);

        prod(i1.addAll(i2) == 0,"addAll seems broken");
        i2.add(4711);
        prod(i1.addAll(i2) == 1,"addAll seems broken still");

        i1.add(Integer.valueOf(10000));
        i2.add(Integer.valueOf(10000));
        prod(i1.equals(i2),"Set equals not properly implemented");

        TreeSet<Integer> i3 = new TreeSet<Integer>(10);
        TreeSet<Integer> i4 = new TreeSet<Integer>(10);
        i3.add(42000);
        i3.add(4200);
        i4.add(4200);
        i4.add(42000);
        prod(i3.equals(i4),"Set equals seems to be ordered...");

        Object[] ints = i1.asArray();
        prod(ints.length == 2,"asArray seems broken 1");
        prod(ints[0].equals(10000),"asArray seems broken 2");
        prod(ints[1].equals(4711) ,"asArray seems broken 3");

        Iterator<Integer> iter = c.iterator();
        Object[] ts = l.asArray();
        for (int i = 0; i < ts.length; ++i) {
            prod(iter.hasNext(),"Iterator seems broken 1");
            prod(iter.next().equals(ts[i]),"Iterator seems broken 2");
        }

        i2.add(Integer.valueOf(42));
        // prod(i2.removeAll(i1) == 2,"removeAll seems broken 1");
        // prod(i2.size() == 1,"removeAll or size seem broken");

        copy = TreeSet.copy(c);

        prod(c.equals(copy) && copy.equals(c),"Equals seem broken and possibly not symmetric!");

        /// Testing MaxCapacity
        try {
            TreeSet<String> stupid = new TreeSet<String>(0);
            stupid.add(new String());
            prod(false,"Managed to add more elements than max capacity");
        } catch (SetFullException sfe) {
            /// All good
        }
        try {
            TreeSet<String> stupid = new TreeSet<String>(0);
            stupid.add("Integer");
            prod(false,"Managed to add more elements than max capacity");
        } catch (SetFullException sfe) {
            /// All good
        }

        try {
            Iterator<Integer> i5 = (new TreeSet<Integer>(0)).iterator();
            i5.next();
        }
        catch (StackUnderflowException e) {
            // All good
        } catch (java.util.NoSuchElementException e) {
            // Also acceptable
        } catch (Exception e) {
            prod(false, "It seems like the Stack doesn't throw the right exception when it is empty");
        }

        Class<?> iteratorClass = Class.forName("TreeSet$SetIterator");
        java.lang.reflect.Field iteratorFields[] = iteratorClass.getDeclaredFields();
        for(java.lang.reflect.Field f : iteratorFields) {
            prod(!f.getType().getSimpleName().equals("ListIterator"), "It seems like you are still using the original implementation");
        }

        try {
            Class<?> stackClass = Class.forName("Stack");

            boolean hasStack = false;
            for(java.lang.reflect.Field f : iteratorFields) {
                hasStack = hasStack || f.getType().getSimpleName().equals("Stack");
            }
            prod(hasStack, "You don't seem to be using a Stack in your iterator");

            java.lang.reflect.TypeVariable<?> stackParameters[] = stackClass.getTypeParameters();
            prod(stackParameters.length > 0, "Your Stack doesn't seem to be generic (it has no type parameters)");

            Class<?> stackInterfaces[] = stackClass.getInterfaces();
            boolean implementsStackI = false;
            for (Class<?> i : stackInterfaces) {
                implementsStackI = implementsStackI || i.getSimpleName().equals("StackI");
            }
            prod(implementsStackI, "Your Stack doesn't seem to implement the StackI interface");

            for(java.lang.reflect.Field f : iteratorFields) {
                hasStack = hasStack || f.getType().getSimpleName().equals("Stack");
            }
        }
        catch (ClassNotFoundException e) {
            prod(false, "It seems like you haven't implemented the Stack class");
        }

        if (soft) {
            System.err.println("-------------------------");
            System.err.println("If you didn't see any error messages above, time to run make test (not make test-soft)!");
        } else {
            System.err.println("All tests pass! Well done!");
        }
    }
}
