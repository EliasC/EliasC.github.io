/// OBS!!! Note that you only need to implement the iterator (and
/// the Stack it's going to use). The rest of the TreeSet class is
/// already implemented.

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.LinkedList;

public class TreeSet<T extends Comparable<T>> extends Collection<T> implements Set<T> {
    private class Node {
        Node left;
        Node right;
        final T element;
        Node(T element) {
            this(element, null, null);
        }
        Node(T element, Node left, Node right) {
            this.element = element;
            this.left = left;
            this.right = right;
        }
    }

    private Node root = null;

    public TreeSet(int maxCapacity) {
        super(maxCapacity);
    }

    /// Adds elem to the set unless it is already in the set
    /// Returns true if elem was added
    public boolean add(T elem) {
        if (this.size() >= this.maxCapacity()) throw new SetFullException();
        if (this.root == null) {
            this.root = new Node(elem);
            return true;
        } else {
            return add(this.root, elem);
        }
    }

    private boolean add(Node node, T elem) {
        int cmp = node.element.compareTo(elem);

        if (cmp == 0) {
            return false;
        } else if (cmp < 0) {
            return addLeft(node, elem);
        } else {
            return addRight(node, elem);
        }
    }

    private boolean addLeft(Node node, T elem) {
        if (node.left == null) {
            node.left = new Node(elem);
            return true;
        } else {
            return add(node.left, elem);
        }
    }

    private boolean addRight(Node node, T elem) {
        if (node.right == null) {
            node.right = new Node(elem);
            return true;
        } else {
            return add(node.right, elem);
        }
    }

    public boolean equals(Object o) {
        if (o instanceof TreeSet) {
            TreeSet<? extends Comparable> otherSet = (TreeSet<? extends Comparable>) o;

            if (otherSet.size() != this.size()) return false;

            for (Object element : otherSet) {
                if (this.contains(element) == false) return false;
            }

            return true;
        } else {
            return false;
        }
    }

    public Collection<T> newEmptyCollection(int maxCapacity) {
        return new TreeSet<T>(maxCapacity);
    }

    public Object[] asArray() {
        Object[] result = new Object[this.size()];
        int index = 0;
        for (T element : this) {
            result[index++] = element;
        }
        return result;
    }

    /// TODO: Most of this code needs to be rewritten!
    private class SetIterator implements Iterator<T> {
        private ListIterator<Node> listIter;

        private void addToList(List<Node> l, Node n) {
            if (n != null) {
                addToList(l, n.left);
                l.add(n);
                addToList(l, n.right);
            }
        }

        public SetIterator(Node root) {
            List<Node> l = new LinkedList<Node>();
            addToList(l, root);
            this.listIter = l.listIterator();
        }

        public T next() {
            Node n = listIter.next();
            return n.element;
        }

        public boolean hasNext() {
            return listIter.hasNext();
        }
    }

    /// Returns iterator for this class
    public Iterator<T> iterator() {
        return new SetIterator(this.root);
    }

    /// If you implement your iterator correctly -- you get this one for free!
    public int addAll(Collection<T> other) {
        int added = 0;
        for (T e : other) {
            this.add(e);
            ++added;
        }
        return added;
    }

    /// If you implement your iterator correctly -- you get this one for free!
    public int size() {
        int result = 0;
        for (T e : this) {
            ++result;
        }
        return result;
    }

    /// If you implement your iterator correctly -- you get this one for free!
    public boolean contains(Object elem) {
        for (T e : this) {
            if (e.equals(elem)) return true;
        }
        return false;
    }
}

/*
// TODO: Use a type parameter called E to get the inner Node class for free!
class Stack... {
    private class Node {
        E elem;
        Node next;

        public Node(E elem, Node next) {
            this.elem = elem;
            this.next = next;
        }
    }
    // TODO: Implement the Stack using the node!
}
*/
