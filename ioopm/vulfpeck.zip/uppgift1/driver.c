#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "queue.h"

int main()
{
  queue_t *q = queue_new();

  assert(q && "queue_new should return something sensible");

  assert(queue_size(q) == 0 && "queue_size for a new queue");

  assert(!queue_take_first(q, NULL) && "queue_take_first from an empty queue");
  assert(!queue_take_last(q, NULL)  && "queue_take_last from an empty queue");
  assert(!queue_peek_first(q, NULL) && "queue_peek_first from an empty queue");
  assert(!queue_peek_last(q, NULL)  && "queue_peek_last from an empty queue");

  queue_offer(q, (elem_t) 1);
  queue_offer(q, (elem_t) 2);
  queue_offer(q, (elem_t) 3);
  queue_offer(q, (elem_t) 4);
  queue_offer(q, (elem_t) 5);
  queue_offer(q, (elem_t) 6);
  assert(queue_size(q) == 6 && "queue_size after taking two elements");

  elem_t e;
  assert(queue_take_first(q, &e) && "queue_take_first 1");
  assert(e.i == 1 && "expecting 1");
  assert(queue_take_first(q, &e) && "queue_take_first 2");
  assert(e.i == 2 && "expecting 2");
  assert(queue_size(q) == 4 && "queue_size after taking two elements");

  assert(queue_peek_first(q, &e) && "queue_peek_first after taking two elements");
  assert(e.i == 3 && "expecting 3");
  assert(queue_size(q) == 4 && "queue_size after taking two elements and peeking");

  assert(queue_take_last(q, &e) && "queue_take_last 1");
  assert(e.i == 6 && "expecting 6");
  assert(queue_take_last(q, &e) && "queue_take_last 2");
  assert(e.i == 5 && "expecting 5");
  assert(queue_size(q) == 2 && "queue_size after taking four elements");

  assert(queue_peek_last(q, &e) && "queue_take_last after taking four elements");
  assert(e.i == 4 && "expecting 4");
  assert(queue_size(q) == 2 && "queue_size after taking four elements and peeking");

  queue_delete(q);

  q = queue_new();

  queue_offer(q, (elem_t) 42);

  assert(queue_take_last(q, &e) && "queue_take_last from a singleton queue");
  assert(e.i == 42 && "expecting 42");

  queue_delete(q);

  return 0;
}
